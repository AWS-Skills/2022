amazon linux ec2
ec2 instance에 iam 설정(poweruser 권한) 